﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blade : MonoBehaviour {

	bool isCutting = false;
	Rigidbody2D rb;
	Camera cam;
	CircleCollider2D circleColider;
	Vector2 previousPosition;
	public float minCuttingVelocity = 0.001f;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		cam = Camera.main;
		circleColider = GetComponent<CircleCollider2D> ();
	}
	
	// Update is called once per frame
	void Update () {
		//check to see if the mouse button is pressed down
		if(Input.GetMouseButtonDown(0)){
			StartCutting ();
		}

			else if(Input.GetMouseButtonUp(0)){
				StopCutting ();
			}
			if(isCutting){
				UpdateCut ();
			}
		
	}

			void StartCutting(){
		isCutting = true;
		circleColider.enabled = false;
}
			void StopCutting(){
		isCutting = false;
		circleColider.enabled = false;
			}

			void UpdateCut(){
		Vector2 newPosition = cam.ScreenToWorldPoint (Input.mousePosition);
		rb.position = newPosition;

		float velocity = (newPosition - previousPosition).magnitude * Time.deltaTime;

		if (velocity > minCuttingVelocity) {
			circleColider.enabled = true;
		} else {
			circleColider.enabled = false;
		}

		previousPosition = newPosition;
	}

	}